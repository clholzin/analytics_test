/**
 * Created by craig on 8/3/2015.
 */
({
    baseUrl: ".",
    name: "vendor/almond",
    include: "require_main",
    preserveLicenseComments: false,
    mainConfigFile: "require_main.js",
    out: "build/require.main.built.js",
    wrapShim: false,
    findNestedDependencies: false
})
