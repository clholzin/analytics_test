##DP10_Analytics_BAE
###**Version 0.1**
####**BAE specific project repo**
-
###Project includes:
* Require.js
* JQuery.js
* Underscore
* KendoUI
* Almond - optimizer
* Moment - calender and time organizer
* FileSaver.js
* jsZip.js
* uglify.js
* Text.js - templates w/ underscore-tpl compiler
* typedArray.js - polyfills for backward browser compatibility
* Blob.js - providing support for IE < 9
* jquery-table2excel.js - Excel xls export